/* This is an automatically generated file. Do not edit. */

/* UniGB-UCS2-H */

static const pdf_range cmap_UniGB_UCS2_H_ranges[] = {
{0x30f8,0x30f9,0x5777},
{0x3127,0x3127,0x2de},
};

static pdf_cmap cmap_UniGB_UCS2_H = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "UniGB-UCS2-H",
	/* usecmap */ "UniGB-X", NULL,
	/* wmode */ 0,
	/* codespaces */ 2, {
		{ 2, 0x0000, 0xd7ff },
		{ 2, 0xe000, 0xffff },
	},
	2, 2, (pdf_range*)cmap_UniGB_UCS2_H_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
